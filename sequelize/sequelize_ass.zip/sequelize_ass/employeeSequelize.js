const Sequelize=require('sequelize');
const dbConfig=require('./db.config')

let sequelize=new Sequelize(dbConfig.DB,dbConfig.USER,dbConfig.PASSWORD,{
    host:dbConfig.HOST,
    dialect:dbConfig.dialect,
    pool:{
        max:dbConfig.pool.max,
        min:dbConfig.pool.min,
        acquire:dbConfig.pool.acquire,
        idle:dbConfig.pool.idle  
    }
})

sequelize.authenticate().then(()=>{
    console.log("---- successfully connected to the database ----");
}).catch((err)=>{
    console.log("---- Database not connected ----");
})


let employeeTable=sequelize.define('employees',{
    empId:{
        type:Sequelize.INTEGER,
        primaryKey:true
    },
    empName:Sequelize.STRING,
    empDept:Sequelize.STRING,
    empDesignation:Sequelize.STRING
},{
    timestamps:false,
    freezeTableName:true
})

employeeTable.sync().then((data)=>{
    console.log(data);
}).catch((err)=>{
    console.log("Table Not Created Due Some Error :"+err);
})
// we can push mupltiple records in single time
// employeeTable.bulkCreate([
//   {empId:101,empName:"Ravi",empDept:"CSE",empDesignation:"SDE"},
//   {empId:102,empName:"Sham",empDept:"CSE",empDesignation:"Fornt end"},
//   {empId:103,empName:"Ramesh",empDept:"ECE",empDesignation:"SE"},
//   {empId:104,empName:"Priya",empDept:"Mech",empDesignation:"ME"},
//   {empId:105,empName:"Meena",empDept:"EEE",empDesignation:"Manager"}
// ])

employeeTable.findAll({raw:true}).then((data)=>{
    console.log(data);
}).catch((err)=>{
    console.log("Got Some Error While Fetching Table :"+err);
})
